package com;

public class A {
    int a=10;
    static int b=20;
    int display()
    {
    	return 30;
    }
   static void display1()
    {
    System.out.println("world");
    }
public static void main(String[] args)
{
	int c=40;
	System.out.println(c);
	A a1=new A();
	System.out.println(a1.a);
	System.out.println(a1.display());
	System.out.println(A.b);
	A.display1();
}
}