package pack;
public class Tns
{
    int a=5;
	static int b=10;
    }
	class cse
	{
	
	public static void main(String[] args)
	{
		int c=7;
		System.out.println(c);
	    Tns b1=new Tns();
		System.out.println(b1.a);
		System.out.println(Tns.b);
	}

}
