package sarika;

public class Protected extends D {

	public static void main(String[] args) {
		Protected p=new Protected();
		p.main();
		System.out.println(p.a);
		System.out.println(p.b);
	}
}
