package sarika;

public class Public {
 public void display()
 {
	 System.out.println("public program");
 }
 
 public static void main(String[] args) {
	 Public p=new Public();
	 p.display();
	 }
}
