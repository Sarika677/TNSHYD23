package sarika;

public class D {
int a=10;
int b=20;
protected void main()
{
	    	System.out.println("hi");
}
}
