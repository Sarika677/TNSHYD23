package sarika;
 class Method4
{
	int b=10;
	static int c=20;
	int display()
	{
		return 0;
	}
	static void display1()
	{
		System.out.println();
		
	}
}
public class Method2
{
	public static void main(String[] args)
	{
		int a=40;
		System.out.println(a);
		Method4 method2=new Method4();
		System.out.println(method2.b);
		method2.display();
		System.out.println(Method4.c);
		Method4.display1();
	}
}
