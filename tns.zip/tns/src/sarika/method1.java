package sarika;

public class method1 {
int b=10;
static int c=20;
int display() {
	return 0;
}
static void display1() {
	System.out.println("10");
}
public static void main(String[] args) {
	int a=10;
	System.out.println(a);
	method1 b1=new method1();
	System.out.println(b1.b);
	b1.display();
	System.out.println(method1.c);
	method1.display1();
}

}
