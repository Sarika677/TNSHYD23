package sarika;

public class Default {
   void display()
   {
	   System.out.println("default program");
   }
   public class Default2{
   }
   public static void main(String[] args) {
	   Default Default =new Default();
	   Default.display();
   }
}
