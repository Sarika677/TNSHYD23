package sarika;

   public class B 
   {
   	private void display()
{
		System.out.println("tns Sessions");
   }
   	public static void main(String[] args) {
   		B b1=new B();
   		b1.display();
   	}
}
	 
